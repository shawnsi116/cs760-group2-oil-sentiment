"""Joint bidirectional commodity training + Iran-war subsample.

Trains news->price and price->news on the SAME walk-forward folds.
Compares full sample vs post-2026-02-28 Iran war / Hormuz crisis window.

Extra methods: interactions, rolling corr, war dummy, multi-output RF,
strong-signal filters.

Contribution (this module)
--------------------------
- Single fold schedule evaluating both directions jointly.
- War / Hormuz crisis subsample (post-2026-02-28) vs pre-war / full sample.
- Interaction features, war dummy, multi-output RF, strong-signal filters.
- joint_bidir_outputs used for final bidirectional / event results.

Taken from online / third-party resources
----------------------------------------
- Models: scikit-learn (HistGradientBoosting, LogisticRegression,
  RandomForest, MultiOutputClassifier).
- Panel from train_sentiment_decay.py; prices originally from Yahoo Finance.
- Event date is a project-defined subsample split for analysis, not a
  third-party labelled dataset.
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parent
PANEL = HERE / "decay_train_outputs" / "panel_daily.csv"
OUT = HERE / "joint_bidir_outputs"
OUT.mkdir(parents=True, exist_ok=True)

WAR_START = pd.Timestamp("2026-02-28")  # 2026 Iran war / Hormuz crisis
SEED = 42


def enrich(df: pd.DataFrame) -> pd.DataFrame:
    d = df.sort_values("date").reset_index(drop=True).copy()
    sent = d["llm_decay_0.7"].fillna(d["llm_sent"])

    # technicals (light)
    delta = d["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    d["rsi_14"] = 100 - (100 / (1 + gain / loss.replace(0, np.nan)))
    d["bb_pos"] = (d["close"] - d["close"].rolling(20).mean()) / (
        2 * d["close"].rolling(20).std().replace(0, np.nan)
    )

    d["sent_z20"] = (sent - sent.rolling(20).mean()) / sent.rolling(20).std()
    d["ret_z20"] = (d["ret_1"] - d["ret_1"].rolling(20).mean()) / d["ret_1"].rolling(20).std()
    d["divergence"] = d["sent_z20"] - d["ret_z20"]
    d["roll_corr_20"] = d["ret_1"].rolling(20).corr(d["llm_sent"])
    d["ret_x_sent"] = d["ret_1"] * sent
    d["mom_x_decay"] = d["mom_5"] * sent
    d["vol_x_neg"] = d["vol_10"] * d["llm_neg"].fillna(0)
    d["war"] = (d["date"] >= WAR_START).astype(float)
    d["war_x_ret"] = d["war"] * d["ret_1"]
    d["war_x_sent"] = d["war"] * sent

    # targets: news -> price
    d["y_price_up_1"] = (d["fwd_ret_1"] > 0).astype(float)
    d["y_price_up_3"] = (d["y_up_3"] if "y_up_3" in d.columns else (d["close"].shift(-3) / d["close"] - 1 > 0)).astype(float)

    # targets: price -> news (future sentiment polarity / volume)
    fut1 = d["llm_sent"].shift(-1)
    fut3 = pd.concat([d["llm_sent"].shift(-i) for i in range(1, 4)], axis=1).mean(axis=1)
    d["y_news_pos_1"] = (fut1 > 0).astype(float)
    d["y_news_pos_3"] = (fut3 > 0).astype(float)
    base_n = d["n_articles"].rolling(10).median()
    d["y_news_vol_1"] = (d["n_articles"].shift(-1) > 1.25 * base_n).astype(float)

    d["strong_sent"] = (sent.abs() > sent.abs().rolling(60).quantile(0.7)).astype(float)
    d["high_vol"] = (d["vol_10"] > d["vol_10"].rolling(60).median()).astype(float)
    return d


SHARED = [
    "ret_1",
    "mom_5",
    "mom_10",
    "vol_10",
    "rsi_14",
    "bb_pos",
    "llm_sent",
    "llm_decay_0.5",
    "llm_decay_0.7",
    "llm_neg",
    "n_articles_roll5",
    "divergence",
    "roll_corr_20",
    "ret_x_sent",
    "mom_x_decay",
    "vol_x_neg",
]

WAR_FEATS = SHARED + ["war", "war_x_ret", "war_x_sent"]


def _clf(name: str):
    if name == "logreg":
        return Pipeline(
            [
                ("sc", StandardScaler()),
                ("clf", LogisticRegression(max_iter=2500, class_weight="balanced", random_state=SEED)),
            ]
        )
    if name == "rf":
        return RandomForestClassifier(
            n_estimators=300, max_depth=6, min_samples_leaf=5, class_weight="balanced_subsample", random_state=SEED, n_jobs=-1
        )
    return HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, max_iter=250, random_state=SEED)


def walk_dual(
    df: pd.DataFrame,
    features: list[str],
    y_price: str,
    y_news: str,
    model: str = "hgb",
    min_train: int = 400,
    test: int = 60,
    step: int = 60,
) -> dict:
    """Same folds: train two heads (or multi-output) and score both directions."""
    cols = [c for c in features if c in df.columns]
    use = df.dropna(subset=cols + [y_price, y_news]).copy()
    use = use[np.isfinite(use[y_price]) & np.isfinite(use[y_news])]
    if len(use) < min_train + test:
        # shrink schedule for short windows (war subsample)
        min_train = max(40, len(use) // 3)
        test = max(15, len(use) // 8)
        step = test
        if len(use) < min_train + test:
            return {"n_folds": 0, "n": 0}

    X = use[cols].to_numpy(float)
    yp = use[y_price].astype(int).to_numpy()
    yn = use[y_news].astype(int).to_numpy()

    pp, tp, pn, tn = [], [], [], []
    # multi-output joint RF on same folds
    jp, jn, jt_p, jt_n = [], [], [], []

    start = min_train
    folds = 0
    while start + test <= len(use):
        Xtr, Xte = X[:start], X[start : start + test]
        yptr, ypte = yp[:start], yp[start : start + test]
        yntr, ynte = yn[:start], yn[start : start + test]
        if len(np.unique(yptr)) < 2 or len(np.unique(yntr)) < 2:
            start += step
            continue

        # separate heads (shared features, same fold)
        cp, cn = _clf(model), _clf(model)
        cp.fit(Xtr, yptr)
        cn.fit(Xtr, yntr)
        pp.extend(cp.predict(Xte).tolist())
        tp.extend(ypte.tolist())
        pn.extend(cn.predict(Xte).tolist())
        tn.extend(ynte.tolist())

        # true joint multi-output
        Ytr = np.column_stack([yptr, yntr])
        joint = MultiOutputClassifier(
            RandomForestClassifier(
                n_estimators=250, max_depth=5, min_samples_leaf=5, random_state=SEED, n_jobs=-1
            )
        )
        joint.fit(Xtr, Ytr)
        pred = joint.predict(Xte)
        jp.extend(pred[:, 0].tolist())
        jn.extend(pred[:, 1].tolist())
        jt_p.extend(ypte.tolist())
        jt_n.extend(ynte.tolist())

        folds += 1
        start += step

    def pack(y_true, y_pred, prefix):
        if not y_true:
            return {f"{prefix}_n": 0, f"{prefix}_acc": np.nan, f"{prefix}_lift": np.nan, f"{prefix}_f1": np.nan}
        yt, yh = np.array(y_true), np.array(y_pred)
        acc = float(accuracy_score(yt, yh))
        base = float(max(yt.mean(), 1 - yt.mean()))
        return {
            f"{prefix}_n": int(len(yt)),
            f"{prefix}_acc": acc,
            f"{prefix}_baseline": base,
            f"{prefix}_lift": acc - base,
            f"{prefix}_f1": float(f1_score(yt, yh, zero_division=0)),
        }

    out = {"n_folds": folds, "min_train": min_train, "test": test, "step": step}
    out.update(pack(tp, pp, "price"))  # news/price features -> price
    out.update(pack(tn, pn, "news"))  # price/news features -> news
    out.update(pack(jt_p, jp, "joint_price"))
    out.update(pack(jt_n, jn, "joint_news"))
    # agreement: both directions correct on same days (only when lengths match)
    if tp and tn and len(tp) == len(tn):
        both = (np.array(tp) == np.array(pp)) & (np.array(tn) == np.array(pn))
        out["both_correct_rate"] = float(both.mean())
    else:
        out["both_correct_rate"] = np.nan
    return out


def run_block(df: pd.DataFrame, period: str, features: list[str], schedule: dict) -> list[dict]:
    rows = []
    configs = [
        ("y_price_up_1", "y_news_pos_1", "h1_polarity"),
        ("y_price_up_3", "y_news_pos_3", "h3_polarity"),
        ("y_price_up_1", "y_news_vol_1", "h1_price_and_vol"),
    ]
    for y_p, y_n, tag in configs:
        for model in ("hgb", "logreg"):
            m = walk_dual(df, features, y_p, y_n, model=model, **schedule)
            rows.append(
                {
                    "period": period,
                    "task": tag,
                    "model": model,
                    "features": "shared+interactions",
                    "n_rows": len(df),
                    **m,
                }
            )
            print(
                f"[{period:10s} {tag:18s} {model:6s}] "
                f"price_acc={m.get('price_acc', np.nan):.3f} (lift {m.get('price_lift', np.nan):+.3f}) | "
                f"news_acc={m.get('news_acc', np.nan):.3f} (lift {m.get('news_lift', np.nan):+.3f}) | "
                f"joint_p={m.get('joint_price_acc', np.nan):.3f} joint_n={m.get('joint_news_acc', np.nan):.3f} | "
                f"folds={m.get('n_folds', 0)}"
            )

    # high-vol / strong-sent subsets (full period only makes sense if enough rows)
    for subset_name, mask in (
        ("high_vol", df["high_vol"] == 1),
        ("strong_sent", df["strong_sent"] == 1),
    ):
        sub = df.loc[mask].copy()
        if len(sub) < 80:
            continue
        m = walk_dual(sub, features, "y_price_up_1", "y_news_pos_1", model="hgb", **schedule)
        rows.append(
            {
                "period": period,
                "task": f"h1_polarity_{subset_name}",
                "model": "hgb",
                "features": "shared+interactions",
                "n_rows": len(sub),
                **m,
            }
        )
        print(
            f"[{period:10s} subset/{subset_name:11s}] "
            f"price={m.get('price_acc', np.nan):.3f} news={m.get('news_acc', np.nan):.3f} n={len(sub)}"
        )
    return rows


def main() -> None:
    raw = pd.read_csv(PANEL, parse_dates=["date"])
    df = enrich(raw)
    df.to_csv(OUT / "panel_joint.csv", index=False)

    full = df.dropna(subset=SHARED + ["y_price_up_1", "y_news_pos_1"]).copy()
    war = full[full["date"] >= WAR_START].copy()
    pre = full[full["date"] < WAR_START].copy()

    print(f"WAR_START = {WAR_START.date()} (2026 Iran war)")
    print(f"Full={len(full)}  Pre-war={len(pre)}  Post-war={len(war)}")
    print(f"Post-war span: {war['date'].min().date()} -> {war['date'].max().date()}")

    rows = []
    rows += run_block(
        full,
        "full",
        WAR_FEATS,
        {"min_train": 400, "test": 60, "step": 60},
    )
    rows += run_block(
        war,
        "post_war",
        SHARED,  # war dummy constant inside subsample
        {"min_train": 50, "test": 20, "step": 15},
    )
    # also train on pre-war only as contrast
    rows += run_block(
        pre,
        "pre_war",
        SHARED,
        {"min_train": 400, "test": 60, "step": 60},
    )

    res = pd.DataFrame(rows)
    res.to_csv(OUT / "results.csv", index=False)

    # summary table: side-by-side directions
    focus = res[res["task"] == "h1_polarity"].copy()
    summary = {
        "war_start": str(WAR_START.date()),
        "war_event": "2026 Iran war / Strait of Hormuz crisis",
        "counts": {"full": int(len(full)), "pre_war": int(len(pre)), "post_war": int(len(war))},
        "h1_polarity_by_period": focus[
            ["period", "model", "price_acc", "price_lift", "news_acc", "news_lift", "joint_price_acc", "joint_news_acc", "both_correct_rate", "n_folds"]
        ].to_dict(orient="records"),
    }
    # best lifts
    if res["price_lift"].notna().any():
        best_p = res.loc[res["price_lift"].idxmax()]
        summary["best_price_lift"] = best_p[["period", "task", "model", "price_acc", "price_lift", "news_acc"]].to_dict()
    if res["news_lift"].notna().any():
        best_n = res.loc[res["news_lift"].idxmax()]
        summary["best_news_lift"] = best_n[["period", "task", "model", "news_acc", "news_lift", "price_acc"]].to_dict()

    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")

    print("\n========== H1 polarity (both directions) ==========")
    cols = [
        "period",
        "model",
        "price_acc",
        "price_lift",
        "news_acc",
        "news_lift",
        "joint_price_acc",
        "joint_news_acc",
        "both_correct_rate",
        "n_folds",
    ]
    print(focus[cols].to_string(index=False))
    print(f"\nWrote {OUT}")


if __name__ == "__main__":
    main()
