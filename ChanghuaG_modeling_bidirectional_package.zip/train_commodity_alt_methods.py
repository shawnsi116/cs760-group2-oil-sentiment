"""Extra commodity methods beyond basic decay / reverse Granger.

Methods:
1) Technical indicators (RSI / MACD / Bollinger position)
2) Sentiment-price divergence (overshoot) feature
3) Volatility-regime models (high vs low vol)
4) Extreme-move classification (|fwd ret| large)
5) Strong-news-only subset
6) VAR impulse-response style summary (price <-> sentiment)
7) Lead-lag cross-correlation scan

Contribution (this module)
--------------------------
- Feature engineering for RSI/MACD/Bollinger, divergence, vol regimes.
- Subset experiments (high-vol, strong-news, extreme moves).
- VAR + orthogonalized IRF-style summaries and lead-lag correlation scan.
- Aggregated results.csv / summary.json / var_irf.json for slides.

Taken from online / third-party resources
----------------------------------------
- RSI / MACD / Bollinger are standard technical formulas (public domain
  market practice); coded from the usual definitions, not copied from a
  specific proprietary source.
- VAR / IRF via ``statsmodels.tsa.api.VAR`` (standard econometrics library).
- Divergence / VAR / lead-lag ideas sketched in group note ``the extra-methods group note``;
  all runnable experiments and reporting are original work in this file.
- Models / metrics: scikit-learn.
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from statsmodels.tsa.api import VAR

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parent
PANEL = HERE / "decay_train_outputs" / "panel_daily.csv"
OUT = HERE / "alt_methods_outputs"
OUT.mkdir(parents=True, exist_ok=True)

SEED = 42
MIN_TRAIN, TEST, STEP = 400, 60, 60


def enrich(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy().sort_values("date").reset_index(drop=True)

    # --- technicals ---
    delta = d["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    d["rsi_14"] = 100 - (100 / (1 + rs))

    ema12 = d["close"].ewm(span=12, adjust=False).mean()
    ema26 = d["close"].ewm(span=26, adjust=False).mean()
    d["macd"] = ema12 - ema26
    d["macd_signal"] = d["macd"].ewm(span=9, adjust=False).mean()
    d["macd_hist"] = d["macd"] - d["macd_signal"]

    ma20 = d["close"].rolling(20).mean()
    sd20 = d["close"].rolling(20).std()
    d["bb_pos"] = (d["close"] - ma20) / (2 * sd20.replace(0, np.nan))

    d["ret_abs"] = d["ret_1"].abs()
    d["vol_regime"] = (d["vol_10"] > d["vol_10"].rolling(60).median()).astype(float)

    # --- divergence / overshoot (idea from the extra-methods group note) ---
    sent = d["llm_decay_0.7"].fillna(d["llm_sent"])
    d["sent_z20"] = (sent - sent.rolling(20).mean()) / sent.rolling(20).std()
    d["ret_z20"] = (d["ret_1"] - d["ret_1"].rolling(20).mean()) / d["ret_1"].rolling(20).std()
    d["divergence"] = d["sent_z20"] - d["ret_z20"]  # sentiment hot but price already ran
    d["divergence_lag1"] = d["divergence"].shift(1)

    # mean-reversion label: after overshoot, does price reverse next day?
    d["y_rev_1"] = ((d["fwd_ret_1"] > 0) == (d["divergence"] < 0)).astype(float)
    # simpler: predict next-day up as before
    d["y_up_1"] = d["y_up_1"]
    d["y_extreme_1"] = np.where(
        d["fwd_ret_1"].abs() < 0.015,
        np.nan,
        (d["fwd_ret_1"] > 0).astype(float),
    )
    d["strong_news"] = (sent.abs() > sent.abs().rolling(60).quantile(0.75)).astype(float)
    return d


FEAT = {
    "tech": ["ret_1", "mom_5", "mom_10", "vol_10", "rsi_14", "macd_hist", "bb_pos"],
    "tech_sent": [
        "ret_1",
        "mom_5",
        "mom_10",
        "vol_10",
        "rsi_14",
        "macd_hist",
        "bb_pos",
        "llm_sent",
        "llm_decay_0.7",
        "llm_neg_decay_0.7",
        "n_articles_roll5",
    ],
    "divergence": [
        "ret_1",
        "mom_5",
        "vol_10",
        "divergence",
        "divergence_lag1",
        "sent_z20",
        "ret_z20",
        "llm_decay_0.7",
    ],
    "full": [
        "ret_1",
        "mom_5",
        "mom_10",
        "vol_10",
        "rsi_14",
        "macd_hist",
        "bb_pos",
        "divergence",
        "divergence_lag1",
        "llm_decay_0.5",
        "llm_decay_0.7",
        "llm_neg_decay_0.7",
        "n_articles_roll5",
        "vol_regime",
    ],
}


def walk_clf(df, features, label, model="hgb", mask=None, min_train=MIN_TRAIN, test=TEST, step=STEP):
    cols = [c for c in features if c in df.columns]
    use = df.copy()
    if mask is not None:
        use = use.loc[mask.fillna(False).to_numpy()]
    use = use.dropna(subset=cols + [label])
    use = use[np.isfinite(use[label])]

    if len(use) < 150:
        return {"n": 0, "acc": np.nan, "f1": np.nan, "auc": np.nan, "baseline": np.nan, "lift": np.nan}

    X = use[cols].to_numpy(float)
    y = use[label].astype(int).to_numpy()
    preds, trues, probas = [], [], []
    min_tr = min(min_train, max(120, len(use) // 3))
    start = min_tr
    te = min(test, max(20, len(use) // 10))
    st = min(step, te)

    while start + te <= len(use):
        Xtr, ytr = X[:start], y[:start]
        Xte, yte = X[start : start + te], y[start : start + te]
        if len(np.unique(ytr)) < 2:
            start += st
            continue
        if model == "logreg":
            clf = Pipeline(
                [
                    ("sc", StandardScaler()),
                    ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=SEED)),
                ]
            )
        else:
            clf = HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, max_iter=250, random_state=SEED)
        clf.fit(Xtr, ytr)
        p = clf.predict(Xte)
        preds.extend(p.tolist())
        trues.extend(yte.tolist())
        if hasattr(clf, "predict_proba"):
            probas.extend(clf.predict_proba(Xte)[:, 1].tolist())
        elif hasattr(clf, "named_steps"):
            probas.extend(clf.predict_proba(Xte)[:, 1].tolist())
        start += st

    if not trues:
        return {"n": 0, "acc": np.nan, "f1": np.nan, "auc": np.nan, "baseline": np.nan, "lift": np.nan}
    yt, yp = np.array(trues), np.array(preds)
    base = float(max(yt.mean(), 1 - yt.mean()))
    acc = float(accuracy_score(yt, yp))
    auc = np.nan
    if probas and len(np.unique(yt)) > 1:
        try:
            auc = float(roc_auc_score(yt, np.array(probas)))
        except Exception:
            auc = np.nan
    return {
        "n": int(len(yt)),
        "acc": acc,
        "f1": float(f1_score(yt, yp, zero_division=0)),
        "auc": auc,
        "baseline": base,
        "lift": acc - base,
    }


def lead_lag(df: pd.DataFrame, max_lag: int = 10) -> pd.DataFrame:
    a = df["ret_1"].fillna(0)
    b = df["llm_sent"].fillna(0)
    rows = []
    for lag in range(-max_lag, max_lag + 1):
        if lag >= 0:
            # sentiment leads price by lag days: corr(sent_t, ret_{t+lag})
            x, y = b.iloc[:-lag or None], a.shift(-lag).iloc[:-lag or None] if lag else (b, a)
            if lag == 0:
                x, y = b, a
            else:
                x = b.iloc[:-lag]
                y = a.iloc[lag:]
        else:
            L = -lag
            # price leads sentiment: corr(ret_t, sent_{t+L})
            x = a.iloc[:-L]
            y = b.iloc[L:]
        c = float(np.corrcoef(x.to_numpy(), y.to_numpy())[0, 1])
        rows.append({"lag": lag, "corr": c, "meaning": "sent_leads_ret" if lag > 0 else ("same_day" if lag == 0 else "ret_leads_sent")})
    return pd.DataFrame(rows)


def var_irf_summary(df: pd.DataFrame, horizon: int = 10) -> dict:
    sub = df[["ret_1", "llm_sent"]].dropna()
    sub = sub - sub.mean()
    model = VAR(sub)
    fit = model.fit(maxlags=5, ic="aic")
    irf = fit.irf(horizon)
    # irf.orth_irfs shape: (H+1, neqs, neqs) response of row to shock in col
    names = list(sub.columns)
    # shock ret -> response llm_sent
    i_ret, i_sent = names.index("ret_1"), names.index("llm_sent")
    path_r2s = irf.orth_irfs[:, i_sent, i_ret]
    path_s2r = irf.orth_irfs[:, i_ret, i_sent]
    return {
        "selected_lags": int(fit.k_ar),
        "shock_price_to_sentiment": [float(x) for x in path_r2s],
        "shock_sentiment_to_price": [float(x) for x in path_s2r],
        "cum_price_to_sentiment": float(np.sum(path_r2s)),
        "cum_sentiment_to_price": float(np.sum(path_s2r)),
        "peak_abs_price_to_sentiment": float(np.max(np.abs(path_r2s))),
        "peak_abs_sentiment_to_price": float(np.max(np.abs(path_s2r))),
    }


def main() -> None:
    raw = pd.read_csv(PANEL, parse_dates=["date"])
    df = enrich(raw)
    df.to_csv(OUT / "panel_enriched.csv", index=False)
    print(f"Enriched panel: {len(df)} rows")

    rows = []

    # 1-2) tech / tech+sent / divergence / full -> next-day direction
    for name, feats in FEAT.items():
        for model in ("hgb", "logreg"):
            m = walk_clf(df, feats, "y_up_1", model=model)
            rows.append({"setup": name, "label": "y_up_1", "subset": "all", "model": model, **m})
            print(f"[{name:12s} {model:6s} y_up_1] acc={m['acc']:.3f} lift={m['lift']:+.3f} auc={m['auc']:.3f}")

    # 3) vol regimes
    for regime, flag in (("high_vol", True), ("low_vol", False)):
        mask = (df["vol_regime"] == 1) if flag else (df["vol_regime"] == 0)
        m = walk_clf(df, FEAT["full"], "y_up_1", model="hgb", mask=mask)
        rows.append({"setup": "full", "label": "y_up_1", "subset": regime, "model": "hgb", **m})
        print(f"[regime {regime:8s}] acc={m['acc']:.3f} lift={m['lift']:+.3f} n={m['n']}")

    # 4) extreme moves
    m = walk_clf(df, FEAT["full"], "y_extreme_1", model="hgb")
    rows.append({"setup": "full", "label": "y_extreme_1", "subset": "all", "model": "hgb", **m})
    print(f"[extreme |ret|>1.5%] acc={m['acc']:.3f} lift={m['lift']:+.3f} n={m['n']}")

    # 5) strong news days only
    mask = df["strong_news"] == 1
    m = walk_clf(df, FEAT["tech_sent"], "y_up_1", model="hgb", mask=mask)
    rows.append({"setup": "tech_sent", "label": "y_up_1", "subset": "strong_news", "model": "hgb", **m})
    print(f"[strong news only] acc={m['acc']:.3f} lift={m['lift']:+.3f} n={m['n']}")

    # divergence as mean-reversion signal (rule): if divergence high, predict down next day
    use = df.dropna(subset=["divergence", "fwd_ret_1"])
    use = use[use["divergence"].abs() > 1.0]
    if len(use):
        pred_down = (use["divergence"] > 0).astype(int)  # overheated sentiment -> expect down? label 0
        # predict up=1 when divergence < 0 (sentiment colder than price)
        pred_up = (use["divergence"] < 0).astype(int)
        y = (use["fwd_ret_1"] > 0).astype(int)
        acc = float(accuracy_score(y, pred_up))
        base = float(max(y.mean(), 1 - y.mean()))
        rows.append(
            {
                "setup": "divergence_rule",
                "label": "y_up_1",
                "subset": "|div|>1",
                "model": "rule",
                "n": int(len(use)),
                "acc": acc,
                "f1": float(f1_score(y, pred_up, zero_division=0)),
                "auc": np.nan,
                "baseline": base,
                "lift": acc - base,
            }
        )
        print(f"[divergence rule |z|>1] acc={acc:.3f} lift={acc-base:+.3f} n={len(use)}")

    res = pd.DataFrame(rows).sort_values("lift", ascending=False)
    res.to_csv(OUT / "results.csv", index=False)

    ll = lead_lag(df)
    ll.to_csv(OUT / "lead_lag_corr.csv", index=False)
    best_ll = ll.iloc[ll["corr"].abs().idxmax()]
    print("\nLead-lag peak |corr|:")
    print(best_ll.to_dict())

    irf = var_irf_summary(df)
    (OUT / "var_irf.json").write_text(json.dumps(irf, indent=2), encoding="utf-8")
    print("\nVAR IRF cumulative effects:")
    print(f"  price shock -> sentiment cum={irf['cum_price_to_sentiment']:.4f} peak||= {irf['peak_abs_price_to_sentiment']:.4f}")
    print(f"  sentiment shock -> price cum={irf['cum_sentiment_to_price']:.4f} peak||= {irf['peak_abs_sentiment_to_price']:.4f}")

    best = res.iloc[0].to_dict()
    summary = {
        "best_by_lift": best,
        "best_acc": float(res["acc"].max()),
        "var_irf": irf,
        "lead_lag_peak": best_ll.to_dict(),
        "takeaway": (
            "Commodity direction stays hard; look for positive lift vs majority baseline, "
            "AUC, regime splits, and IRF asymmetry (price->news vs news->price)."
        ),
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")

    print("\n========== TOP by lift ==========")
    print(res.head(12).to_string(index=False))
    print(f"\nWrote {OUT}")


if __name__ == "__main__":
    main()
