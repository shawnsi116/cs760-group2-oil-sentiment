"""Replicate all modeling results for this contributor's package.

Run from this directory:

    python run_replicate_results.py

Order:
  1) train_sentiment_decay.py      -> decay_train_outputs/
  2) train_price_to_news.py        -> price_to_news_outputs/
  3) train_commodity_alt_methods.py-> alt_methods_outputs/
  4) train_joint_bidirectional.py  -> joint_bidir_outputs/

Contribution: orchestration entry point for full-result replication.
Third-party: only standard library + the train_* modules above.
"""

from __future__ import annotations

import runpy
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = [
    "train_sentiment_decay.py",
    "train_price_to_news.py",
    "train_commodity_alt_methods.py",
    "train_joint_bidirectional.py",
]


def main() -> None:
    missing = [p for p in ("sentiment_llm_daily.csv", "sentiment_cb_daily.csv") if not (HERE / p).exists()]
    if missing:
        raise SystemExit(f"Missing required input(s): {missing}. Place them next to this script.")

    sys.path.insert(0, str(HERE))
    for name in SCRIPTS:
        path = HERE / name
        if not path.exists():
            raise SystemExit(f"Missing script: {path}")
        print("\n" + "=" * 72)
        print(f"RUNNING {name}")
        print("=" * 72)
        runpy.run_path(str(path), run_name="__main__")

    print("\n" + "=" * 72)
    print("Replication finished. Check summary.json under each *_outputs/ folder.")
    print("=" * 72)


if __name__ == "__main__":
    main()
