"""Reverse direction: oil price -> future news sentiment / volume.

Complements train_sentiment_decay.py (news -> price). Reports walk-forward
classification accuracy and bidirectional Granger causality p-values.

Contribution (this module)
--------------------------
- Reverse task: price features → future news polarity / volume spikes.
- Bidirectional Granger tests on returns vs LLM sentiment.
- Walk-forward classification/regression reporting and summary.json.

Taken from online / third-party resources
----------------------------------------
- Granger implementation: ``statsmodels.tsa.stattools.grangercausalitytests``
  (classic econometric test; we apply it to our panel, not inventing the test).
- Models / metrics: scikit-learn.
- Panel input: ``decay_train_outputs/panel_daily.csv`` from train_sentiment_decay.py.
- Bidirectional Granger idea from group note ``the extra-methods group note``; code and
  evaluation design implemented here.
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, mean_absolute_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from statsmodels.tsa.stattools import grangercausalitytests

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parent
PANEL = HERE / "decay_train_outputs" / "panel_daily.csv"
OUT_DIR = HERE / "price_to_news_outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_SEED = 42
MIN_TRAIN = 400
TEST_SIZE = 60
STEP = 60
SENT_THR = 0.05  # |sentiment| below this -> Neutral / skipped for binary


def load_panel() -> pd.DataFrame:
    if not PANEL.exists():
        raise SystemExit(f"Missing {PANEL}. Run train_sentiment_decay.py first.")
    df = pd.read_csv(PANEL, parse_dates=["date"]).sort_values("date").reset_index(drop=True)

    # Forward news outcomes (what price today might "cause" later)
    for h in (1, 3, 5):
        df[f"fwd_llm_sent_{h}"] = df["llm_sent"].shift(-h)
        df[f"fwd_llm_roll_{h}"] = df["llm_sent"].shift(-1).rolling(h).mean().shift(-(h - 1))
        # mean of next h days' sentiment (causal from today's info)
        fut = pd.concat([df["llm_sent"].shift(-i) for i in range(1, h + 1)], axis=1)
        df[f"fwd_llm_mean_{h}"] = fut.mean(axis=1)
        df[f"fwd_n_mean_{h}"] = pd.concat([df["n_articles"].shift(-i) for i in range(1, h + 1)], axis=1).mean(axis=1)

        df[f"y_news_pos_{h}"] = (df[f"fwd_llm_mean_{h}"] > 0).astype(float)
        df[f"y_news_bull_{h}"] = np.where(
            df[f"fwd_llm_mean_{h}"].abs() < SENT_THR,
            np.nan,
            (df[f"fwd_llm_mean_{h}"] > 0).astype(float),
        )
        # volume spike: next-h mean articles > past-10 median
        base = df["n_articles"].rolling(10).median()
        df[f"y_vol_spike_{h}"] = (df[f"fwd_n_mean_{h}"] > 1.25 * base).astype(float)

    # Same-day news (leaky / contemporaneous — media often narrates today's move)
    df["y_news_same"] = (df["llm_sent"] > 0).astype(float)
    df["y_news_same_thr"] = np.where(
        df["llm_sent"].abs() < SENT_THR,
        np.nan,
        (df["llm_sent"] > 0).astype(float),
    )
    return df


PRICE_FEATS = ["ret_1", "mom_5", "mom_10", "vol_10"]
PRICE_RICH = PRICE_FEATS + ["close"]  # close level often weak; kept for ablation


def walk_forward_clf(df, features, label, model="hgb", min_train=MIN_TRAIN, test_size=TEST_SIZE, step=STEP):
    cols = [c for c in features if c in df.columns]
    use = df.dropna(subset=cols + [label]).copy()
    use = use[np.isfinite(use[label])]
    X = use[cols].to_numpy(float)
    y = use[label].astype(int).to_numpy()

    preds, trues, folds = [], [], []
    start = min_train
    while start + test_size <= len(use):
        X_tr, y_tr = X[:start], y[:start]
        X_te, y_te = X[start : start + test_size], y[start : start + test_size]
        if len(np.unique(y_tr)) < 2:
            start += step
            continue
        if model == "logreg":
            clf = Pipeline(
                [
                    ("sc", StandardScaler()),
                    ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=RANDOM_SEED)),
                ]
            )
        else:
            clf = HistGradientBoostingClassifier(
                max_depth=4, learning_rate=0.05, max_iter=200, random_state=RANDOM_SEED
            )
        clf.fit(X_tr, y_tr)
        p = clf.predict(X_te)
        preds.extend(p.tolist())
        trues.extend(y_te.tolist())
        folds.append(accuracy_score(y_te, p))
        start += step

    if not trues:
        return {"n": 0, "acc": np.nan, "f1": np.nan, "baseline": np.nan}
    yt, yp = np.array(trues), np.array(preds)
    return {
        "n": int(len(yt)),
        "acc": float(accuracy_score(yt, yp)),
        "f1": float(f1_score(yt, yp, zero_division=0)),
        "baseline": float(max(yt.mean(), 1 - yt.mean())),
        "fold_acc_mean": float(np.mean(folds)),
        "n_folds": len(folds),
    }


def walk_forward_reg(df, features, target, min_train=MIN_TRAIN, test_size=TEST_SIZE, step=STEP):
    cols = [c for c in features if c in df.columns]
    use = df.dropna(subset=cols + [target]).copy()
    X = use[cols].to_numpy(float)
    y = use[target].to_numpy(float)
    preds, trues = [], []
    start = min_train
    while start + test_size <= len(use):
        reg = HistGradientBoostingRegressor(max_depth=4, learning_rate=0.05, max_iter=200, random_state=RANDOM_SEED)
        reg.fit(X[:start], y[:start])
        p = reg.predict(X[start : start + test_size])
        preds.extend(p.tolist())
        trues.extend(y[start : start + test_size].tolist())
        start += step
    if not trues:
        return {"n": 0, "mae": np.nan, "r2": np.nan, "dir_acc": np.nan}
    yt, yp = np.array(trues), np.array(preds)
    dir_acc = float(((yt > 0) == (yp > 0)).mean())
    return {
        "n": int(len(yt)),
        "mae": float(mean_absolute_error(yt, yp)),
        "r2": float(r2_score(yt, yp)),
        "dir_acc": dir_acc,
        "baseline_dir": float(max((yt > 0).mean(), 1 - (yt > 0).mean())),
    }


def granger_block(df: pd.DataFrame, maxlag: int = 5) -> dict:
    """Bidirectional Granger on stationary-ish series: ret_1 <-> llm_sent."""
    sub = df[["ret_1", "llm_sent"]].dropna().copy()
    # mild demean
    sub["ret_1"] = sub["ret_1"] - sub["ret_1"].mean()
    sub["llm_sent"] = sub["llm_sent"] - sub["llm_sent"].mean()

    out = {}
    # columns order for grangercausalitytests: [y, x] tests whether x Granger-causes y
    for name, data in {
        "price_causes_sentiment": sub[["llm_sent", "ret_1"]],
        "sentiment_causes_price": sub[["ret_1", "llm_sent"]],
    }.items():
        try:
            res = grangercausalitytests(data, maxlag=maxlag)
            pvals = {lag: float(res[lag][0]["ssr_ftest"][1]) for lag in range(1, maxlag + 1)}
            out[name] = {
                "pvalues_by_lag": pvals,
                "min_pvalue": float(min(pvals.values())),
                "significant_any_lag_5pct": bool(min(pvals.values()) < 0.05),
            }
        except Exception as exc:
            out[name] = {"error": str(exc)}
    return out


def weekly_panel(df: pd.DataFrame) -> pd.DataFrame:
    w = (
        df.set_index("date")
        .resample("W-FRI")
        .agg(
            {
                "close": "last",
                "ret_1": "sum",
                "mom_5": "last",
                "mom_10": "last",
                "vol_10": "last",
                "llm_sent": "mean",
                "n_articles": "sum",
            }
        )
        .dropna(subset=["close"])
        .reset_index()
    )
    w["fwd_llm_mean_1"] = w["llm_sent"].shift(-1)
    w["y_news_pos_1"] = (w["fwd_llm_mean_1"] > 0).astype(float)
    w["y_news_bull_1"] = np.where(
        w["fwd_llm_mean_1"].abs() < SENT_THR,
        np.nan,
        (w["fwd_llm_mean_1"] > 0).astype(float),
    )
    w["y_vol_spike_1"] = (w["n_articles"].shift(-1) > 1.25 * w["n_articles"].rolling(4).median()).astype(float)
    return w


def main() -> None:
    df = load_panel()
    print(f"Daily panel: {len(df)} rows")

    rows = []

    # --- Classification: price -> future news polarity ---
    for h in (1, 3, 5):
        for label, tag in (
            (f"y_news_pos_{h}", "all_days"),
            (f"y_news_bull_{h}", "skip_flat_news"),
            (f"y_vol_spike_{h}", "volume_spike"),
        ):
            for model in ("hgb", "logreg"):
                m = walk_forward_clf(df, PRICE_FEATS, label, model=model)
                rows.append(
                    {
                        "freq": "D",
                        "horizon": h,
                        "task": tag,
                        "label": label,
                        "features": "price_only",
                        "model": model,
                        **m,
                    }
                )
                print(f"[D h={h} {tag:16s} {model:6s}] acc={m['acc']:.3f} base={m['baseline']:.3f} n={m['n']}")

        # regression: predict mean future sentiment level
        r = walk_forward_reg(df, PRICE_FEATS, f"fwd_llm_mean_{h}")
        rows.append(
            {
                "freq": "D",
                "horizon": h,
                "task": "reg_fwd_sent",
                "label": f"fwd_llm_mean_{h}",
                "features": "price_only",
                "model": "hgb_reg",
                "n": r["n"],
                "acc": r["dir_acc"],
                "f1": None,
                "baseline": r["baseline_dir"],
                "fold_acc_mean": None,
                "n_folds": None,
                "mae": r["mae"],
                "r2": r["r2"],
            }
        )
        print(f"[D h={h} reg_fwd_sent     ] dir_acc={r['dir_acc']:.3f} R2={r['r2']:.3f} MAE={r['mae']:.3f}")

    # --- Contemporaneous (media narrates today's move) ---
    for label, tag in (("y_news_same", "same_day"), ("y_news_same_thr", "same_day_skip_flat")):
        m = walk_forward_clf(df, PRICE_FEATS, label, model="hgb")
        rows.append(
            {
                "freq": "D",
                "horizon": 0,
                "task": tag,
                "label": label,
                "features": "price_only",
                "model": "hgb",
                **m,
            }
        )
        print(f"[D same-day {tag:16s}] acc={m['acc']:.3f}  (contemporaneous, not causal claim)")

    # --- Weekly ---
    w = weekly_panel(df)
    w.to_csv(OUT_DIR / "panel_weekly_reverse.csv", index=False)
    for label, tag in (("y_news_pos_1", "all_days"), ("y_news_bull_1", "skip_flat_news"), ("y_vol_spike_1", "volume_spike")):
        m = walk_forward_clf(
            w,
            ["ret_1", "mom_5", "mom_10", "vol_10"],
            label,
            model="hgb",
            min_train=80,
            test_size=20,
            step=20,
        )
        rows.append(
            {
                "freq": "W",
                "horizon": 1,
                "task": tag,
                "label": label,
                "features": "price_only",
                "model": "hgb",
                **m,
            }
        )
        print(f"[W h=1 {tag:16s}] acc={m['acc']:.3f} base={m['baseline']:.3f} n={m['n']}")

    # --- Granger ---
    g = granger_block(df, maxlag=5)
    (OUT_DIR / "granger.json").write_text(json.dumps(g, indent=2), encoding="utf-8")
    print("\nGranger causality (min p across lags 1..5):")
    for k, v in g.items():
        if "min_pvalue" in v:
            print(f"  {k}: min_p={v['min_pvalue']:.4g}  sig@5%={v['significant_any_lag_5pct']}")
        else:
            print(f"  {k}: {v}")

    res = pd.DataFrame(rows)
    # sort classification-like rows by acc
    res_path = OUT_DIR / "walk_forward_results.csv"
    res.to_csv(res_path, index=False)

    clf_only = res[res["model"] != "hgb_reg"].copy()
    best = clf_only.loc[clf_only["acc"].idxmax()] if clf_only["acc"].notna().any() else None
    causal = clf_only[clf_only["horizon"] > 0]
    best_causal = causal.loc[causal["acc"].idxmax()] if len(causal) and causal["acc"].notna().any() else None

    summary = {
        "question": "Can oil price movements forecast subsequent news sentiment/volume?",
        "best_any_acc": None if best is None else float(best["acc"]),
        "best_any_setup": None if best is None else best.to_dict(),
        "best_causal_acc": None if best_causal is None else float(best_causal["acc"]),
        "best_causal_setup": None if best_causal is None else best_causal.to_dict(),
        "granger": g,
        "hit_90": bool(best_causal is not None and best_causal["acc"] >= 0.90),
        "interpretation": (
            "If same-day accuracy >> forward accuracy, news largely narrates price moves. "
            "If price->sentiment Granger is significant, reverse channel exists."
        ),
    }
    (OUT_DIR / "summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")

    print("\n========== SUMMARY ==========")
    show = res.sort_values(["freq", "horizon", "acc"], ascending=[True, True, False])
    print(show.drop(columns=[c for c in ["mae", "r2"] if c in show.columns], errors="ignore").to_string(index=False))
    print("\nBest causal (horizon>0):")
    print(json.dumps(summary["best_causal_setup"], indent=2, default=str))
    print(f"\nWrote {res_path}")


if __name__ == "__main__":
    main()
