"""Walk-forward oil-direction models: decay sentiment + forward returns.

Uses LLM daily sentiment (CrudeBERT daily is near-constant Neutral and is
kept only as a dead-feature ablation). No same-day label leakage in the
main setups; a leaky contemporary baseline is reported for contrast.

Contribution (this module — group modeling / Person responsible for
news↔price experiments)
--------------------------------------------------------------
- Built the daily/weekly panel joining LLM sentiment with WTI prices.
- Implemented causal exponential sentiment decay features (lambda grid).
- Defined forward-return labels (h = 1, 3, 5) with no same-day leakage.
- Walk-forward expanding-window evaluation and leaky same-day contrast.
- Wrote result CSVs / summary.json used in the final presentation.

Taken from online / third-party resources (not claimed as original)
------------------------------------------------------------------
- WTI prices via Yahoo Finance (`yfinance`), ticker CL=F (fallback USO).
- Classifiers / metrics: scikit-learn (HistGradientBoosting, LogisticRegression,
  GradientBoosting, accuracy / F1 / ROC-AUC).
- Sentiment input CSVs produced by the group's Person 3 CrudeBERT + DeepSeek
  pipeline (upstream); this script only consumes the daily aggregates.
- Decay design idea adapted from the group's internal note
  ``the further-improvement group note`` (Sentiment Decay Model); implementation here is original.
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import yfinance as yf
from sklearn.ensemble import GradientBoostingClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parent
SENT_LLM = HERE / "sentiment_llm_daily.csv"
SENT_CB = HERE / "sentiment_cb_daily.csv"
PRICE_CACHE = HERE / "wti_price_daily.csv"
OUT_DIR = HERE / "decay_train_outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_SEED = 42
LAMBDAS = [0.3, 0.5, 0.7, 0.9]
HORIZONS = [1, 3, 5]
MIN_TRAIN = 400
TEST_SIZE = 60
STEP = 60


def load_sentiment() -> pd.DataFrame:
    llm = pd.read_csv(SENT_LLM, parse_dates=["date"]).rename(
        columns={
            "sent_mean": "llm_sent",
            "neg_share": "llm_neg",
            "pos_share": "llm_pos",
            "neu_share": "llm_neu",
            "n_articles": "n_articles",
        }
    )
    cb = pd.read_csv(SENT_CB, parse_dates=["date"]).rename(
        columns={
            "sent_mean": "cb_sent",
            "neg_share": "cb_neg",
            "pos_share": "cb_pos",
            "neu_share": "cb_neu",
        }
    )[["date", "cb_sent", "cb_neg", "cb_pos", "cb_neu"]]
    return llm.merge(cb, on="date", how="left")


def load_price() -> pd.DataFrame:
    if PRICE_CACHE.exists():
        px = pd.read_csv(PRICE_CACHE, parse_dates=["date"])
        if len(px) > 100:
            return px.sort_values("date").reset_index(drop=True)

    # WTI front-month futures; fallback to USO ETF if futures blocked
    for ticker in ("CL=F", "USO"):
        raw = yf.download(ticker, start="2019-12-01", end="2026-09-20", progress=False, auto_adjust=True)
        if raw is None or raw.empty:
            continue
        if isinstance(raw.columns, pd.MultiIndex):
            raw.columns = [c[0] for c in raw.columns]
        close_col = "Close" if "Close" in raw.columns else raw.columns[0]
        px = raw.reset_index()[["Date", close_col]].rename(columns={"Date": "date", close_col: "close"})
        px["date"] = pd.to_datetime(px["date"]).dt.tz_localize(None)
        px = px.dropna().sort_values("date").reset_index(drop=True)
        px["ticker"] = ticker
        px.to_csv(PRICE_CACHE, index=False)
        print(f"[price] downloaded {ticker}: {len(px)} rows -> {PRICE_CACHE.name}")
        return px
    raise RuntimeError("Could not download WTI/USO prices")


def decay_series(x: pd.Series, lam: float, k: int = 5) -> pd.Series:
    """Causal exponential decay over past k days including today."""
    w = np.array([(lam**i) for i in range(k)][::-1], dtype=float)
    w = w / w.sum()
    vals = x.fillna(0.0).to_numpy(dtype=float)
    out = np.full(len(vals), np.nan)
    for t in range(k - 1, len(vals)):
        out[t] = float(np.dot(vals[t - k + 1 : t + 1], w))
    return pd.Series(out, index=x.index)


def build_panel(freq: str = "D") -> pd.DataFrame:
    sent = load_sentiment()
    px = load_price()
    df = px.merge(sent, on="date", how="inner").sort_values("date").reset_index(drop=True)

    df["ret_1"] = df["close"].pct_change()
    df["ret_5"] = df["close"].pct_change(5)
    df["vol_10"] = df["ret_1"].rolling(10).std()
    df["mom_5"] = df["close"].pct_change(5)
    df["mom_10"] = df["close"].pct_change(10)

    for lam in LAMBDAS:
        df[f"llm_decay_{lam}"] = decay_series(df["llm_sent"], lam, k=5)
        df[f"llm_neg_decay_{lam}"] = decay_series(df["llm_neg"], lam, k=5)

    df["llm_sent_lag1"] = df["llm_sent"].shift(1)
    df["llm_sent_roll3"] = df["llm_sent"].rolling(3).mean()
    df["llm_sent_roll5"] = df["llm_sent"].rolling(5).mean()
    df["n_articles_roll5"] = df["n_articles"].rolling(5).mean()

    for h in HORIZONS:
        # Label uses only future closes relative to today's close (no leakage).
        df[f"fwd_ret_{h}"] = df["close"].shift(-h) / df["close"] - 1.0
        df[f"y_up_{h}"] = (df[f"fwd_ret_{h}"] > 0).astype(float)
        # Skip near-zero moves (noise band)
        df[f"y_up_thr_{h}"] = np.where(
            df[f"fwd_ret_{h}"].abs() < 0.003,
            np.nan,
            (df[f"fwd_ret_{h}"] > 0).astype(float),
        )

    if freq == "W":
        df = (
            df.set_index("date")
            .resample("W-FRI")
            .agg(
                {
                    "close": "last",
                    "llm_sent": "mean",
                    "llm_neg": "mean",
                    "llm_pos": "mean",
                    "n_articles": "sum",
                    "cb_sent": "mean",
                    **{f"llm_decay_{lam}": "last" for lam in LAMBDAS},
                    **{f"llm_neg_decay_{lam}": "last" for lam in LAMBDAS},
                }
            )
            .dropna(subset=["close"])
            .reset_index()
        )
        df["ret_1"] = df["close"].pct_change()
        df["mom_5"] = df["close"].pct_change(2)
        df["vol_10"] = df["ret_1"].rolling(4).std()
        for h in (1, 2):
            df[f"fwd_ret_{h}"] = df["close"].shift(-h) / df["close"] - 1.0
            df[f"y_up_{h}"] = (df[f"fwd_ret_{h}"] > 0).astype(float)
            df[f"y_up_thr_{h}"] = np.where(
                df[f"fwd_ret_{h}"].abs() < 0.005,
                np.nan,
                (df[f"fwd_ret_{h}"] > 0).astype(float),
            )
    return df


FEATURE_SETS = {
    "price_only": ["ret_1", "mom_5", "mom_10", "vol_10"],
    "raw_sent": ["ret_1", "mom_5", "mom_10", "vol_10", "llm_sent", "llm_neg", "llm_pos", "n_articles"],
    "decay_sent": [
        "ret_1",
        "mom_5",
        "mom_10",
        "vol_10",
        "llm_sent",
        "llm_sent_lag1",
        "llm_sent_roll3",
        "llm_sent_roll5",
        "n_articles_roll5",
        "llm_decay_0.5",
        "llm_decay_0.7",
        "llm_neg_decay_0.5",
        "llm_neg_decay_0.7",
    ],
    "decay_only": [
        "llm_sent",
        "llm_sent_lag1",
        "llm_sent_roll5",
        "llm_decay_0.3",
        "llm_decay_0.5",
        "llm_decay_0.7",
        "llm_decay_0.9",
        "llm_neg_decay_0.5",
        "n_articles_roll5",
    ],
    # Intentionally leaky: same-day return as feature + same-day direction as label
    "leaky_same_day": ["ret_1", "llm_sent", "llm_neg", "mom_5", "vol_10"],
}


def walk_forward(
    df: pd.DataFrame,
    features: list[str],
    label: str,
    model_name: str = "hgb",
    min_train: int = MIN_TRAIN,
    test_size: int = TEST_SIZE,
    step: int = STEP,
) -> dict:
    cols = [c for c in features if c in df.columns]
    use = df.dropna(subset=cols + [label]).copy()
    use = use[np.isfinite(use[label])]
    y_all = use[label].astype(int).to_numpy()
    X_all = use[cols].to_numpy(dtype=float)

    preds, trues, folds = [], [], []
    start = min_train
    while start + test_size <= len(use):
        tr_end = start
        te_end = start + test_size
        X_tr, y_tr = X_all[:tr_end], y_all[:tr_end]
        X_te, y_te = X_all[tr_end:te_end], y_all[tr_end:te_end]
        if len(np.unique(y_tr)) < 2 or len(X_te) == 0:
            start += step
            continue

        if model_name == "logreg":
            clf = Pipeline(
                [
                    ("scaler", StandardScaler()),
                    ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=RANDOM_SEED)),
                ]
            )
        elif model_name == "gb":
            clf = GradientBoostingClassifier(random_state=RANDOM_SEED)
        else:
            clf = HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, max_iter=200, random_state=RANDOM_SEED)

        clf.fit(X_tr, y_tr)
        p = clf.predict(X_te)
        preds.extend(p.tolist())
        trues.extend(y_te.tolist())
        folds.append(accuracy_score(y_te, p))
        start += step

    if not trues:
        return {"n": 0, "acc": np.nan, "f1": np.nan, "auc": np.nan, "baseline": np.nan, "fold_acc_mean": np.nan}

    y_true = np.array(trues)
    y_pred = np.array(preds)
    # AUC needs scores; approximate with predicted class if no proba
    try:
        if model_name == "logreg":
            auc = np.nan  # already aggregated hard labels only
        else:
            auc = np.nan
        # recompute with last model not available; skip proper AUC on pooled hard labels
        auc = roc_auc_score(y_true, y_pred) if len(np.unique(y_true)) > 1 else np.nan
    except Exception:
        auc = np.nan

    return {
        "n": int(len(y_true)),
        "acc": float(accuracy_score(y_true, y_pred)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "auc": float(auc) if auc == auc else None,
        "baseline": float(max(y_true.mean(), 1 - y_true.mean())),
        "fold_acc_mean": float(np.mean(folds)) if folds else None,
        "n_folds": len(folds),
        "features": cols,
    }


def sentiment_sign_rule(df: pd.DataFrame, sent_col: str, label: str) -> dict:
    use = df.dropna(subset=[sent_col, label]).copy()
    use = use[use[sent_col].abs() > 0.05]
    if use.empty:
        return {"n": 0, "acc": np.nan}
    pred = (use[sent_col] > 0).astype(int)
    y = use[label].astype(int)
    return {"n": int(len(use)), "acc": float(accuracy_score(y, pred)), "baseline": float(max(y.mean(), 1 - y.mean()))}


def main() -> None:
    print("Building daily panel...")
    daily = build_panel("D")
    daily.to_csv(OUT_DIR / "panel_daily.csv", index=False)
    print(f"Daily rows after merge: {len(daily)} | ticker cache: {PRICE_CACHE.name}")

    print("Building weekly panel...")
    weekly = build_panel("W")
    weekly.to_csv(OUT_DIR / "panel_weekly.csv", index=False)
    print(f"Weekly rows: {len(weekly)}")

    rows = []

    # --- Main daily experiments ---
    for h in HORIZONS:
        label = f"y_up_{h}"
        for feat_name, feats in FEATURE_SETS.items():
            if feat_name == "leaky_same_day":
                continue
            for model in ("hgb", "logreg"):
                # shorter history features may miss mom_10 on weekly; daily ok
                use_feats = [f for f in feats if f in daily.columns]
                metrics = walk_forward(daily, use_feats, label, model_name=model)
                rows.append(
                    {
                        "freq": "D",
                        "horizon": h,
                        "label": label,
                        "features": feat_name,
                        "model": model,
                        **{k: v for k, v in metrics.items() if k != "features"},
                    }
                )
                print(
                    f"[D h={h} {feat_name:12s} {model:6s}] "
                    f"acc={metrics['acc']:.3f} baseline={metrics['baseline']:.3f} n={metrics['n']}"
                )

        # thresholded labels (skip flat days)
        thr_label = f"y_up_thr_{h}"
        metrics = walk_forward(daily, FEATURE_SETS["decay_sent"], thr_label, model_name="hgb")
        rows.append(
            {
                "freq": "D",
                "horizon": h,
                "label": thr_label,
                "features": "decay_sent",
                "model": "hgb",
                **{k: v for k, v in metrics.items() if k != "features"},
            }
        )
        print(f"[D h={h} decay_sent   thr   ] acc={metrics['acc']:.3f} n={metrics['n']}")

        rule = sentiment_sign_rule(daily, "llm_decay_0.7", label)
        rows.append(
            {
                "freq": "D",
                "horizon": h,
                "label": label,
                "features": "sign(llm_decay_0.7)",
                "model": "rule",
                "n": rule["n"],
                "acc": rule["acc"],
                "f1": None,
                "auc": None,
                "baseline": rule.get("baseline"),
                "fold_acc_mean": None,
                "n_folds": None,
            }
        )

    # --- Weekly ---
    w_feats = [
        c
        for c in [
            "ret_1",
            "mom_5",
            "vol_10",
            "llm_sent",
            "llm_neg",
            "llm_pos",
            "n_articles",
            "llm_decay_0.5",
            "llm_decay_0.7",
            "llm_neg_decay_0.5",
        ]
        if c in weekly.columns
    ]
    for h in (1, 2):
        label = f"y_up_{h}"
        for model in ("hgb", "logreg"):
            metrics = walk_forward(
                weekly,
                w_feats,
                label,
                model_name=model,
                min_train=80,
                test_size=20,
                step=20,
            )
            rows.append(
                {
                    "freq": "W",
                    "horizon": h,
                    "label": label,
                    "features": "decay_sent_weekly",
                    "model": model,
                    **{k: v for k, v in metrics.items() if k != "features"},
                }
            )
            print(f"[W h={h} weekly_decay {model:6s}] acc={metrics['acc']:.3f} n={metrics['n']}")

    # --- Leaky contrast (same-day ret as label AND feature) ---
    leaky = daily.dropna(subset=["ret_1"]).copy()
    leaky["y_same"] = (leaky["ret_1"] > 0).astype(float)
    metrics = walk_forward(leaky, FEATURE_SETS["leaky_same_day"], "y_same", model_name="hgb")
    rows.append(
        {
            "freq": "D",
            "horizon": 0,
            "label": "y_same_day_LEAKY",
            "features": "leaky_same_day",
            "model": "hgb",
            **{k: v for k, v in metrics.items() if k != "features"},
        }
    )
    print(f"[LEAKY same-day] acc={metrics['acc']:.3f}  << not a valid claim")

    res = pd.DataFrame(rows).sort_values(["freq", "horizon", "acc"], ascending=[True, True, False])
    res_path = OUT_DIR / "walk_forward_results.csv"
    res.to_csv(res_path, index=False)

    valid = res[res["label"] != "y_same_day_LEAKY"].copy()
    best = valid.loc[valid["acc"].idxmax()] if len(valid) and valid["acc"].notna().any() else None

    summary = {
        "best_valid_setup": None if best is None else best.to_dict(),
        "best_valid_acc": None if best is None else float(best["acc"]),
        "target_acc": 0.90,
        "hit_90": bool(best is not None and best["acc"] >= 0.90),
        "note": (
            "90% directional accuracy on oil with causal walk-forward splits "
            "is not expected; leaky same-day setup is reported only as a warning."
        ),
    }
    (OUT_DIR / "summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")

    print("\n========== SUMMARY ==========")
    print(res.to_string(index=False))
    print("\nBest causal setup:")
    print(json.dumps(summary, indent=2, default=str))
    print(f"\nWrote {res_path}")


if __name__ == "__main__":
    main()
